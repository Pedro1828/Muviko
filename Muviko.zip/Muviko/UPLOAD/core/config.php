<?php
$domain = 'http://localhost/flixer';

// Database Configuration
$db['host'] = 'localhost';
$db['user'] = 'root';
$db['pass'] = 'root';
$db['name'] = 'flixer';

$db = new mysqli($db['host'], $db['user'], $db['pass'], $db['name']) or die('MySQL Error');

error_reporting(0);
