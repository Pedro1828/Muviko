<?php

class Core {
	public $db;
	public $domain;
	public $settings;
	public $language_array;

	function __construct($db,$domain) {
		$this->db = $db;
		$this->domain = $domain;
		$this->getSettings();
	}

	public function getDomain() {
		return $this->domain;
	}

	public function hashPassword($password) {
		return hash('sha512',$password);
	}

	public function getSettings() {
		$settings = $this->db->query("SELECT * FROM settings");
		$settings = $settings->fetch_object();
		$this->settings = $settings;
	}

	public function getUploadsPath() {
		return $this->domain.'/uploads';
	}

	public function getExtendPath($in_theme_dir=false) {
		$settings = $this->settings;
		if($in_theme_dir == false) {
			return 'themes/'.$settings->theme.'/extend.php';
		} else {
			return '../extend.php';	
		}
	}

	public function getHeaderPath() {
		$settings = $this->settings;
		return 'themes/'.$settings->theme.'/inc/top.php';
	}

	public function getPagePath($page) {
		$settings = $this->settings;
		return 'themes/'.$settings->theme.'/layout/'.$page.'.php';
	}

	public function getFooterPath() {
		$settings = $this->settings;
		return 'themes/'.$settings->theme.'/inc/bottom.php';
	}

	public function getThemePath() {
		$settings = $this->settings;
		return $this->domain.'/themes/'.$settings->theme;
	}

	public function getLanguage($sub_dir='') {
		$path = dirname(dirname(__FILE__));
		if(isset($_SESSION['fl_language'])) {
			$language = $path.'/languages/'.$_SESSION['fl_language'].'/language.php';
		} else {
			$language = $path.'/languages/'.$this->settings->default_language.'/language.php';
		}
		require($language);
		$this->language_array = $lang;
	}

	public function translate($str) {
		return $this->language_array[$str];
	}

	public function getCountryByIP($ip) {
		$html = file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip);
		$html = unserialize($html);
		return $html['geoplugin_countryName'];
	}
}

class Session extends Core {
	public $session_id;
	public $user_id;
	public $user_email;
	public $user_name;
	public $user_phone;
	public $profile_id;
	public $is_admin;
	public $user;

	public function generateSessionID() {
		return substr(md5(time()),0,10);
	}

	public function startUserSession($session) {
		if(!empty($session['fl_session_id'])) {
			$_SESSION['fl_session_id'] = $this->session_id = $session['fl_session_id'];
			$_SESSION['fl_user_id'] = $this->user_id = $session['fl_user_id'];
			$_SESSION['fl_language'] = $session['fl_language'];
			if(isset($session['is_admin']) && $session['is_admin'] == 1) {
				$_SESSION['is_admin'] = $this->is_admin = $session['is_admin'];
			}
			if(isset($this->user_id)) {
				$this->setUser($this->user_id);
			}
		}
	}

	public function verifySession($login_required) {
		$session_id = $this->session_id;
		if(!empty($session_id)) {
			$session = $this->db->query("SELECT * FROM sessions WHERE session_id='".$session_id."'");
			$session = $session->fetch_object();
			if($session->is_active == 0) {
				if($login_required == true) {
					header('Location: '.$this->getDomain().'/logout.php');
					exit;
				} else {
					return false;
				}
			} else {
				return true;
			}
		} else {
			if($login_required == true) {
				header('Location: '.$this->getDomain().'/logout.php');
				exit;
			} else {
				return false;
			}
		}
	}

	public function endSession() {
		$this->db->query("UPDATE sessions SET is_active='0' WHERE session_id='".$this->session_id."'");
		session_destroy();
		header('Location: index.php');
		exit;
	}

	public function endSessions() {
		$this->db->query("UPDATE sessions SET is_active='0' WHERE user_id='".$this->user_id."'");
		session_destroy();
		header('Location: index.php');
		exit;
	}

	public function getSessions() {
		$sessions = $this->db->query("SELECT * FROM sessions WHERE user_id='".$this->user_id."'");
		return $sessions;
	}

	public function readableSessionStatus($status) {
		if($status == 1) {
			return 'Active';
		} else {
			return 'Inactive';
		}
	}

	public function setUser($user_id) {
		$user = $this->db->query("SELECT * FROM users WHERE id='".$user_id."' LIMIT 1");
		if($user->num_rows >= 1) {
			$user = $user->fetch_object();
			$this->user = $user;
		}
	}
}

class Movie extends Session {
	public $movie_id;

	public function setMovie($movie_id){
		$this->movie_id = $movie_id;
	}

	public function canWatch($free_to_watch) {
		if($this->user->is_subscriber == 1 || $free_to_watch == 1 || $this->user->is_admin == 1) {
			return true;
		} else {
			return false;
		}
	}

	public function subscriberAction() {
		if($this->user->is_subscriber == 1 || $this->user->is_admin == 1) {
			return true;
		} else {
			return false;
		}
	}

	public function getSuggestions($movie_genres) {
		$genres = explode(',',$movie_genres);
		$primary_genre = $genres[0];
		$suggestions = $this->db->query("SELECT * FROM movies WHERE (movie_genres LIKE '%".$primary_genre."%' OR movie_genres 
			LIKE '%".$primary_genre."' OR movie_genres LIKE '".$primary_genre."%') AND id != ".$this->movie_id." ORDER BY RAND() LIMIT 10");
		return $suggestions;
	}

	public function isKid() {
		if(isset($_SESSION['is_kid'])) {
			return true;
		} else {
			return false;
		}
	}

	public function getFeaturedMovie() {
		if(isset($_SESSION['is_kid'])) {
			$featured_movie = $this->db->query("SELECT * FROM movies WHERE is_featured='1' AND is_kid_friendly='1' ORDER BY RAND() LIMIT 1");
		} else {
			$featured_movie = $this->db->query("SELECT * FROM movies WHERE is_featured='1' ORDER BY RAND() LIMIT 1");
		}
		return $featured_movie->fetch_object();
	}

	public function getSeasons() {
		return $this->db->query("SELECT * FROM seasons WHERE movie_id='".$this->movie_id."' ORDER BY season_number ASC");
	}

	public function getDefaultSeason() {
		$default = $this->db->query("SELECT * FROM seasons WHERE movie_id='".$this->movie_id."' ORDER BY season_number ASC LIMIT 1");
		$default = $default->fetch_object();
		return $default;
	}

	public function movieGenresToText($movie_genres) {
		$genres_id = explode(',',$movie_genres);
		$arr = $genres_id;
		foreach($genres_id as $genre_id) {
			$genre = $this->db->query("SELECT * FROM genres WHERE id='".$genre_id."' LIMIT 1");
			$genre = $genre->fetch_object();
			echo $genre->genre_name;
			if(next($arr)) {
				echo ', ';
			}
		}
	}
}

class Admin extends Movie {
	public function verifyAdmin($redirect) {
		if($redirect == true) {
			if($this->is_admin == 1) {
				if(basename($_SERVER['PHP_SELF']) == 'index.php') {
					header('Location: dashboard.php');
					exit;
				}
			} else {
				header('Location: '.$this->getDomain().'/logout.php');
				exit;
			}
		} else {
			if($this->is_admin == 1) {
				return true;
			} else {
				return false;
			}
		}
	}

	public function getUserRank($is_admin,$is_subscriber) {
		if($is_admin == 0 && $is_subscriber == 0) {
			return 'User';
		} elseif($is_admin == 0 && $is_subscriber == 1) {
			return 'Subscriber';
		} else {
			return 'Admin';
		}
	}

	public function getKidFriendly($is_kid_friendly) {
		if($is_kid_friendly == 1) {
			return '<i class="ti-check"></i>';
		} else {
			return '<i class="ti-close"></i>';
		}
	}

	public function getThemes($theme_dir) {
		$themes = scandir($theme_dir);
		return $themes;
	}

	public function trimNames($names) {
		$names = explode(' ',$names);
		$names[1] = substr($names[1],0,1);
		return $names[0].' '.$names[1].'.';
	}
}

class Data extends Admin {
	public function getStatistics() {
		$users = $this->db->query("SELECT COUNT(*) AS num FROM users");
		$users = $users->fetch_object();
		$videos = $this->db->query("SELECT COUNT(*) AS num FROM movies");
		$videos = $videos->fetch_object();
		$episodes = $this->db->query("SELECT COUNT(*) AS num FROM episodes");
		$episodes = $episodes->fetch_object();
		$result = new stdClass();
		$result->users = $users->num;
		$result->videos = $videos->num;
		$result->episodes = $episodes->num;
		return $result;
	}

	public function getUsers() {
		$users = $this->db->query("SELECT * FROM users ORDER BY id DESC");
		return $users;
	}

	public function getUser($user_id=false,$find=false,$column=false) {
		if($find == false) {
			$user = $this->db->query("SELECT * FROM users WHERE id='".$user_id."'");
			$user = $user->fetch_object();
		} else {
			$user = $this->db->query("SELECT * FROM users WHERE ".$column."='".$find."'");
			$user = $user->fetch_object();
		}
		return $user;
	}

	public function getGenres($limit=false,$empty=true) {
		if(is_numeric($limit)) {
			$limit = 'LIMIT '.$limit;
		} else {
			$limit = '';
		}
		if($empty == true) {
			$genres = $this->db->query("SELECT * FROM genres ORDER BY id DESC ".$limit."");
		} else {
			$genres = $this->db->query("SELECT * FROM genres AS genre WHERE EXISTS 
				(SELECT id FROM movies WHERE movie_genres LIKE CONCAT('%', genre.id ,'%')) ORDER BY id DESC ".$limit."");
		}
		return $genres;
	}

	public function getGenre($genre_id) {
		$genre = $this->db->query("SELECT * FROM genres WHERE id='".$genre_id."'");
		$genre = $genre->fetch_object();
		return $genre;
	}

	public function getMovies() {
		$movies = $this->db->query("SELECT * FROM movies ORDER BY id DESC");
		return $movies;
	}

	public function getMovie($movie_id=false,$movie_page=false) {
		if($movie_page == true) {
			$movie_id = $this->movie_id;
		}
		$movie = $this->db->query("SELECT * FROM movies WHERE id='".$movie_id."'");
		$movie = $movie->fetch_object();
		return $movie;
	}

	public function getSeason($season_id) {
		$season = $this->db->query("SELECT * FROM seasons WHERE id='".$season_id."'");
		$season = $season->fetch_object();
		return $season;
	}

	public function getEpisodes() {
		$episodes = $this->db->query("SELECT * FROM episodes ORDER BY id DESC");
		return $episodes;
	}

	public function getEpisode($episode_id) {
		$episode = $this->db->query("SELECT * FROM episodes WHERE id='".$episode_id."'");
		$episode = $episode->fetch_object();
		return $episode;
	}

	public function getActors($movie=false,$movie_id=false) {
		if($movie == false) {
			$actors = $this->db->query("SELECT * FROM actors ORDER BY id DESC");
		} else {
			$actors = array();
			$relations = $this->db->query("SELECT * FROM actor_relations WHERE movie_id='".$this->movie_id."' ORDER BY id ASC");
			while($relation = $relations->fetch_object()) {
				$actor = $this->db->query("SELECT * FROM actors WHERE id='".$relation->actor_id."'");
				$actor = $actor->fetch_object();
				$actors[] = $actor;
			}
		}
		return $actors;
	}

	public function getActor($actor_id) {
		$actor = $this->db->query("SELECT * FROM actors WHERE id='".$actor_id."'");
		$actor = $actor->fetch_object();
		return $actor;
	}

	public function getPages() {
		$pages = $this->db->query("SELECT * FROM pages ORDER BY id ASC");
		return $pages;
	}

	public function getPage($page_id) {
		$page = $this->db->query("SELECT * FROM pages WHERE id='".$page_id."'");
		$page = $page->fetch_object();
		return $page;
	}
} 